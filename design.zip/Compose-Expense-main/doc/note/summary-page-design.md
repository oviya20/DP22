```
1 section in out
Date Juni 2022
Header summary
Amount this month
Amount in and out

2 section
See more
Latest 5 items transaction
data Amount Category Account Date

Top expense
See more
5 category in percent
data category comparison
```

