// TODO refactor navigation code
MainFlow
SplashFlow
- splash
AuthFlow
- login
TransactionDetailFlow
- transaction detail
- select account
- select transfer account
- select category
AccountDetailFlow
- account detail
- select category
SettingFlow
- setting
- select theme
- select language
- logout
HomeFlow
TransactionSummaryFlow
- Transaction summary
- all transaction screen
- top expense screen
BalanceSummaryFlow
- Balance summary

// Tablet
MainFlow
SplashFlow
- splash
AuthFlow
- login


SettingFlow
    - setting
    - select theme
    - select language
    - logout
HomeFlow
    TransactionSummaryFlow
        - Transaction summary
            
            
BalanceSummaryFlow
    - Balance summary

            
RIGHT
AllTransactionFlow
- all transaction screen
TopExpenseFlow
- top expense screen

TransactionDetailFlow
- transaction detail
- select account
- select transfer account
- select category

AccountDetailFlow
- account detail
- select category
