// TODO 1: Recent selected category
// TODO 2: Measure room performance

// TODO 6: Adjust trx type component
// TODO 7: search currency
