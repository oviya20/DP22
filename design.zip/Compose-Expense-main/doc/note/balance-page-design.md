```
Net amount
All time amount

Account
Account name, color, amount, account type

History in out each month
```
