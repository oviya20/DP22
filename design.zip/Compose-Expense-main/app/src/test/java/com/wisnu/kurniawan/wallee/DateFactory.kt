package com.wisnu.kurniawan.wallee

import java.time.LocalDate
import java.time.LocalDateTime

object DateFactory {
    val constantDate: LocalDateTime = LocalDateTime.of(2021, 1, 1, 0, 0, 0, 0)
    val constantDate2: LocalDate = LocalDate.of(2021, 1, 1)
}
