package com.wisnu.kurniawan.wallee.foundation.window

enum class Dimension { WIDTH, HEIGHT }
