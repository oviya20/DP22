package com.wisnu.kurniawan.wallee.features.onboarding.ui

sealed interface OnboardingEffect {
    object ClosePage : OnboardingEffect
}
