package com.wisnu.kurniawan.wallee.model

enum class TransactionType {
    INCOME,
    EXPENSE,
    TRANSFER
}
