package com.wisnu.kurniawan.wallee.foundation.di

object DiName {

    const val DISPATCHER_IO = "Dispatcher.IO"
    const val DISPATCHER_MAIN = "Dispatcher.MAIN"

}
