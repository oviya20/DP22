package com.wisnu.kurniawan.wallee.model

data class User(val email: String = "")
