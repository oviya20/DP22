package com.wisnu.kurniawan.wallee.model

enum class AccountType {
    E_WALLET,
    BANK,
    CASH,
    INVESTMENT,
    OTHERS
}
