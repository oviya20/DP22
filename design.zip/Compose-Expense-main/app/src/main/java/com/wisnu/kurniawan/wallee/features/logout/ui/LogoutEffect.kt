package com.wisnu.kurniawan.wallee.features.logout.ui

sealed class LogoutEffect {
    object NavigateToSplash : LogoutEffect()
}
