package com.wisnu.kurniawan.wallee.features.account.detail.ui

sealed interface AccountDetailEffect {
    object ClosePage : AccountDetailEffect
}
