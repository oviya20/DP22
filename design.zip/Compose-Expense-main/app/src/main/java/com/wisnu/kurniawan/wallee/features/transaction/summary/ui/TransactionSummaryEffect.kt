package com.wisnu.kurniawan.wallee.features.transaction.summary.ui

sealed interface TransactionSummaryEffect {
    object Initial: TransactionSummaryEffect
}
