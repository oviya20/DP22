package com.wisnu.kurniawan.wallee.foundation.window

enum class FoldState { FLAT, HALF_OPENED }
