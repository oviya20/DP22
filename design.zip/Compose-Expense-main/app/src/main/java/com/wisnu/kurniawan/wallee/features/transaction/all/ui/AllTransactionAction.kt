package com.wisnu.kurniawan.wallee.features.transaction.all.ui

sealed interface AllTransactionAction {
}
