package com.wisnu.kurniawan.wallee.features.logout.ui

sealed class LogoutAction {
    object ClickLogout : LogoutAction()
}
