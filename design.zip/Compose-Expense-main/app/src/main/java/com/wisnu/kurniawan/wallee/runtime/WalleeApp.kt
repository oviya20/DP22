package com.wisnu.kurniawan.wallee.runtime

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WalleeApp : Application()
