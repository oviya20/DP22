package com.wisnu.kurniawan.wallee.features.transaction.all.ui

sealed interface AllTransactionEffect {
    object Initial : AllTransactionEffect
}
