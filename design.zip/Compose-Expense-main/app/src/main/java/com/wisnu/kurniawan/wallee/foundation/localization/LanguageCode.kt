package com.wisnu.kurniawan.wallee.foundation.localization

object LanguageCode {
    const val ENGLISH: String = "en"
    const val INDONESIA: String = "id"
}
