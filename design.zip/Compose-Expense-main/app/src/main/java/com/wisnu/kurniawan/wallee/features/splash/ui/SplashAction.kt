package com.wisnu.kurniawan.wallee.features.splash.ui

sealed class SplashAction {
    object AppLaunch : SplashAction()
}
