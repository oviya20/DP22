package com.wisnu.kurniawan.wallee.model

data class Credential(val token: String)
