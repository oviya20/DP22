package com.wisnu.kurniawan.wallee.features.balance.summary.ui

sealed interface BalanceSummaryEffect
