package com.wisnu.kurniawan.wallee.foundation.extension

const val DEFAULT_ACCOUNT_ID = "default"
