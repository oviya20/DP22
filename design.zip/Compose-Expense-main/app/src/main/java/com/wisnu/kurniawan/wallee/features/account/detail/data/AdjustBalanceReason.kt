package com.wisnu.kurniawan.wallee.features.account.detail.data

enum class AdjustBalanceReason {
    FORGOT_FOR_UPDATE,
    LONG_TIME_NOT_UPDATE
}
