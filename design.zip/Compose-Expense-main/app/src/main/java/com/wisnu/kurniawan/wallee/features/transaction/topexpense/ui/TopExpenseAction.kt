package com.wisnu.kurniawan.wallee.features.transaction.topexpense.ui

sealed interface TopExpenseAction {
}
