package com.wisnu.kurniawan.wallee.foundation.theme

const val AlphaDisabled = 0.3F
const val AlphaMedium = 0.55F
const val AlphaHigh = 1F

const val DividerAlpha = 0.12f
